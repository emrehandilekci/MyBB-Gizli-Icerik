<?php
/* Versiyon: 1.0 - MyBB 1.6.x, 1.8x */

$plugins->add_hook("parse_message", "gizli_icerik_run");
function gizli_icerik_info()
{
    return array(
        'name'        => 'Gizli İçerik Eklentisi',
        'description' => 'Konularda gizlemek istediğiniz kısımları, [gizli]gizli içerik[/gizli] etiketlerini kullanarak gizlemenizi sağlar. Kurulum içermez aktifleştirmeniz ve pasifleştirmeniz yeterlidir.',
        'website'     => 'http://mybb.com/',
        'author'      => 'emrehandilekci',
        'authorsite'  => 'https://github.com/emrehandilekci',
        'version'     => '1.0',
    "compatibility"   => "16*, 18*",
        
    );
}
function gizli_icerik_activate()
{
}
function gizli_icerik_deactivate()
{
}
function gizli_icerik_run($message)
{
global $db, $n, $mybb;

if ( ($mybb->user['uid'] != "0")) {
    $search="/\[gizli](.*)\[\/gizli\]/siU";
    $replace="<div style=\"border-bottom: 1px dotted rgb(102, 102, 102); margin: 5px 0pt;\"><center><b>Aşağıdan gizli içeriğe erişebilirsiniz.</b><center></div><div style='display: block;'>\\1</div>";
    $message = preg_replace($search, $replace, $message);
    $message = str_replace("\'", "'", $message);
    $message = $message;
} else {

    $searcharray[]="/\[gizli](.*)\[\/gizli\]/siU";
    $replacearray[]="<center><img src=\"images/gizli-icerik.png\" style=\"vertical-align: middle;\" alt=\"Hide Post\" title=\"Gizli İçerik\" border=\"0\" /></center>";
    $message = preg_replace($searcharray, $replacearray, $message);
    $message = str_replace("\'", "'", $message);
}

return $message;
}
?>